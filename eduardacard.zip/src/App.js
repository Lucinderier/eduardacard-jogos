import logo from './logo.svg';
import './App.css';
import Meucard from './card/card';
import { useEffect, useState } from 'react'; 
import { listarCatalogo } from './API/api'; 

function App() {
  return (<div className="App">
      <Criarcards />
      <NovosJogos />
  </div>
  )
}

function Criarcards() {   
  return ( 
    <div className="card-container"> {/* Corrija a classe para .card-container */}
     

      <Meucard 
        capa= "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_50WSYncOAsmoFOUb7ndWq7KBhfx9y0x5VA&s"
        titulo="Bratz: The Movie"
        desenvolvedora="Blitz game" 
      />
      <Meucard 
        capa="https://www.gamespot.com/a/uploads/scale_medium/mig/0/9/2/7/2220927-cover.jpg"
        titulo="winx club"
        desenvolvedora="Powerhead Games" 
      />
      <Meucard
      capa="https://m.media-amazon.com/images/M/MV5BMTIzNDM0NjAxNV5BMl5BanBnXkFtZTcwNDExNTAzMQ@@._V1_FMjpg_UX1000_.jpg"
      titulo="Bratz: Rock Angelz"
      desenvolvedora="Blitz Games"
      />
      <Meucard
      capa="https://m.media-amazon.com/images/I/71DZcz0bOvL._SL1500_.jpg"
      titulo="Bratz: Forever Diamondz"
      desenvolvedora="Blitz Games"
      />
      <Meucard
      capa="https://vgmsite.com/soundtracks/bratz-girlz-really-rock-ps2-wii-gamerip-2008/Wii_game_cover.jpg"
      titulo="Bratz: Girlz Really Rock"
      desenvolvedora="Blitz Games"
      />
      <Meucard
      capa="https://products.eneba.games/resized-products/68V0osEOLnLPg6ULG3k1ZJyJWLY9_nrE7o-zmNb07io_350x200_3x-0.jpeg"
      titulo="Disney Enchanted Journey"
      desenvolvedora="Papaya Studios"
      />

    </div>
  );
}

function NovosJogos() {
  const [catalogo, setCatalogo] = useState([]);

  useEffect(() => {
    listarCatalogo().then((dados) => {
      setCatalogo(dados);
    });
  }, []);

  return (
    <div className="card-container"> {/* Corrija a classe para .card-container */}
      {catalogo.map((jogo, i) => (
        <Meucard 
          key={i} 
          capa={jogo.urlCapa}
          titulo={jogo.nome}
          desenvolvedora={jogo.desenvolvedora}
        />
      ))}
    </div>
  );
}

export default App;

