function Sobre() {
    return (
        <div className="Sobre">
            <h1>oiiie</h1>
        </div>
    )
}

export default Sobre;