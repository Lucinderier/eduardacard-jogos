import '../App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import App from '../App';
import { listarCatalogo } from '../API/api';
import Sobre from '../Sobre/Sobre';
function Rotas() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<App/>}>
                <Route index element={<listarCatalogo/>} />
                <Route path='sobre' element={<Sobre />}>
                </Route>
                </Route>
            </Routes>
        </BrowserRouter>
    );
}


export default Rotas;

