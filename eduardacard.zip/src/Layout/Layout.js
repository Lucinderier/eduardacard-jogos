import logo from './logo.svg';
import './App.css';
import Meucard from './card/card';
import { useEffect, useState } from 'react'; 
import { listarCatalogo } from './API/api'; 


export default function Layout() {
    return<div className="App">
        <Criarcards />
    <NovosJogos />
</div>
}